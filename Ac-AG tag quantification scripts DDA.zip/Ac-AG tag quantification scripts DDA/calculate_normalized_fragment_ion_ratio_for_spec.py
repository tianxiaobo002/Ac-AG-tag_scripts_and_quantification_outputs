def normalize_ratio_for_spec (work_path,fragment_ions_matched_intens):

    ###Based on the theroretical ratio, calculating the normalize numeber
    desired_ratio = input ('please indicattes the mixed sample ratio')
    normalize_number = 0
    for each_ratio_number in desired_ratio:
        normalize_number = normalize_number + int(each_ratio_number)

    ###For 3-plex labeled fragment ion, if any channel lost the signal, the one will be discarded. Here, defining the minimum number of macthed 3-plex labeled ion.
    ###If the spectrum has less matched 3-plex labeled, the spectrum will be marked as 'not counted'
    
    file_path = work_path
    
    gather_quantification_ratio_for_all_scan_number = {}

    for each_scan_number in fragment_ions_matched_intens.keys():
        
        gather_quantification_ratio_for_all_scan_number [each_scan_number] = []
        
        all_kinds_of_quantification_ions = []
        for each_kind_of_quantification_ion in fragment_ions_matched_intens [each_scan_number]:
            if each_kind_of_quantification_ion [0][:-2] not in all_kinds_of_quantification_ions and each_kind_of_quantification_ion [0] != 'spectrum_information':
                all_kinds_of_quantification_ions.append (each_kind_of_quantification_ion [0][:-2])
        ion_name_match_three_plex_intensity = {}
        for each_kind_of_quantification_ion in all_kinds_of_quantification_ions:
            ion_name_match_three_plex_intensity [each_kind_of_quantification_ion] = []
        for each_kind_of_quantification_ion in fragment_ions_matched_intens [each_scan_number]:
            if each_kind_of_quantification_ion [0] != 'spectrum_information':
                ion_name_match_three_plex_intensity [each_kind_of_quantification_ion [0][:-2]].append (each_kind_of_quantification_ion)
        collect_three_intensities = [0,0,0]
        sum_three_intensities_number = 0
        normalized_ratio = [0,0,0]
        for each_key in ion_name_match_three_plex_intensity:
            
            for each_quanti_ion in ion_name_match_three_plex_intensity [each_key]:
                '''print (each_quanti_ion [0])
                print (each_quanti_ion [0][-2:])'''
                    
                if each_quanti_ion [0][-2:] == '+0':
                    collect_three_intensities [0] = round(float (each_quanti_ion [3]),4)
                if each_quanti_ion [0][-2:] == '+1':
                    collect_three_intensities [1] = round(float (each_quanti_ion [3]),4)
                if each_quanti_ion [0][-2:] == '+2':
                    collect_three_intensities [2] = round(float (each_quanti_ion [3]),4)
            sum_three_intensities = sum (collect_three_intensities)
            sum_three_intensities_number = sum (collect_three_intensities)
            
            if sum_three_intensities != 0:
                normalized_ratio [0] = round(collect_three_intensities [0]/(sum_three_intensities/normalize_number),2)
                normalized_ratio [1] = round(collect_three_intensities [1]/(sum_three_intensities/normalize_number),2)
                normalized_ratio [2] = round(collect_three_intensities [2]/(sum_three_intensities/normalize_number),2)
                
            ion_name_match_three_plex_intensity [each_key].insert (0,sum_three_intensities_number)
            ion_name_match_three_plex_intensity [each_key].insert (0,collect_three_intensities)
            ion_name_match_three_plex_intensity [each_key].insert (0,normalized_ratio)

            collect_three_intensities = [0,0,0]
            sum_three_intensities_number = []
            normalized_ratio = [0,0,0]
        need_to_be_removed_key = []
        
        for each_key in ion_name_match_three_plex_intensity:
            if 0 in ion_name_match_three_plex_intensity [each_key][1]:
                need_to_be_removed_key.append (each_key)
        if fragment_ions_matched_intens [each_scan_number][-1:][0][1][-1:][0][1] == 1:

            for each_key in ion_name_match_three_plex_intensity:
                if each_key not in need_to_be_removed_key and 'second'in each_key:
                    need_to_be_removed_key.append (each_key)
        else:

            for each_key in ion_name_match_three_plex_intensity:
                if each_key not in need_to_be_removed_key and 'second'not in each_key:
                    need_to_be_removed_key.append (each_key)
            
        for each_key in need_to_be_removed_key:
            del ion_name_match_three_plex_intensity [each_key]
                
        if len (ion_name_match_three_plex_intensity) >1:
            
            combined_name = ''
            combined_ratio = [0,0,0]
            combined_single_intensity = [0,0,0]
            combined_sum_intensity = 0

        
            for each_key in ion_name_match_three_plex_intensity:
                combined_name = combined_name + each_key
                combined_single_intensity [0] = combined_single_intensity [0] + ion_name_match_three_plex_intensity[each_key][1][0]
                combined_single_intensity [1] = combined_single_intensity [1] + ion_name_match_three_plex_intensity[each_key][1][1]
                combined_single_intensity [2] = combined_single_intensity [2] + ion_name_match_three_plex_intensity[each_key][1][2]
            combined_sum_intensity = sum (combined_single_intensity)
            if combined_sum_intensity != 0:
                combined_ratio [0] = round(combined_single_intensity [0]/(combined_sum_intensity/normalize_number),2)
                combined_ratio [1] = round(combined_single_intensity [1]/(combined_sum_intensity/normalize_number),2)
                combined_ratio [2] = round(combined_single_intensity [2]/(combined_sum_intensity/normalize_number),2)
                
            ion_name_match_three_plex_intensity.clear()
            ion_name_match_three_plex_intensity [str (combined_name)]= []
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_sum_intensity)
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_single_intensity)
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_ratio)
            
                
                
            
        
        gather_quantification_ratio_for_all_scan_number [each_scan_number].append (ion_name_match_three_plex_intensity)
        gather_quantification_ratio_for_all_scan_number [each_scan_number].append (fragment_ions_matched_intens [each_scan_number] [-1:])

    
    import csv

    write_by_rows = [['scan_number','quantification_name','normalized_ratio','nor_ra_+0','nor_ra_+1','nor_ra_+2','inten_+0','inten_+1','inten_+2','to_inten_3cha']]
    
    for scan_number in gather_quantification_ratio_for_all_scan_number.keys():
        
        
        new_line = [str (scan_number)]
        for each_key in gather_quantification_ratio_for_all_scan_number[scan_number][0]:
            new_line.append (str (each_key))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][0]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][1]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][2]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][0]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][1]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][2]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][2]))
        
        write_by_rows.append (new_line)
           
    output_file = open (file_path + 'Spectrum_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(output_file)
    print ('preparing Spectrum_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    ########################################################################################################################## Calculating ratios on peptide level

    top_n_spectrum_for_peptide_ratio = int(input ('please indicates top N spectrum used for peptide ratio'))
    all_intensity_collection_peptide_level = {}
    all_peptides_collection = []
    
    for scan_number in gather_quantification_ratio_for_all_scan_number.keys():
        
        ### the next step is to creat the intensities collection grouped by peptide sequence, the first item is the all 3-plex intensities collection which will be used to select top n
        ### the second item is the records of the specific spectrum, the third is the peptide information
        temp_peptide_sequence = gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1]
        
        if gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1] not in all_peptides_collection and gather_quantification_ratio_for_all_scan_number[scan_number][0] != []:
            all_peptides_collection.append (temp_peptide_sequence)
            all_intensity_collection_peptide_level [temp_peptide_sequence] = []

            for every_quantification_ion in gather_quantification_ratio_for_all_scan_number[scan_number][0]:

                
                ###print ('temp_peptide_sequence = gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1]',temp_peptide_sequence)
                ###print (gather_quantification_ratio_for_all_scan_number[scan_number][0])
                
                        
                all_intensity_collection_peptide_level [temp_peptide_sequence].append([gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]])
                all_intensity_collection_peptide_level [temp_peptide_sequence].append ({scan_number:gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]})
                all_intensity_collection_peptide_level [temp_peptide_sequence].append (gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0])
        else:
            for every_quantification_ion in gather_quantification_ratio_for_all_scan_number[scan_number][0]:
                ###print ('gather_quantification_ratio_for_all_scan_number[scan_number][0]',gather_quantification_ratio_for_all_scan_number[scan_number][0])
                ###print ('repeated peptide sequence',all_intensity_collection_peptide_level [temp_peptide_sequence])
                if all_intensity_collection_peptide_level [temp_peptide_sequence] != []:
                    all_intensity_collection_peptide_level [temp_peptide_sequence][0].append(gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1])
                    all_intensity_collection_peptide_level [temp_peptide_sequence][1][scan_number] = gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]
    
    ### the next is to find out the top n spectra
                
    import heapq
    empty_sequence = []
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        ###print (all_intensity_collection_peptide_level [each_peptide_seq])
        if all_intensity_collection_peptide_level [each_peptide_seq] == []:
            empty_sequence.append (each_peptide_seq)
    for each_empty_peptide_seq in empty_sequence:
        
        del all_intensity_collection_peptide_level [each_empty_peptide_seq]
       
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():    
        all_intensity_collection_peptide_level [each_peptide_seq][0] =heapq.nlargest(top_n_spectrum_for_peptide_ratio,all_intensity_collection_peptide_level [each_peptide_seq][0])
    
    
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        
        top_n_spectra_sum_intensity = [0,0,0]
        for each_top_selected_intensity in all_intensity_collection_peptide_level [each_peptide_seq][0]:
            
            top_n_spectra_sum_intensity [0]= round((top_n_spectra_sum_intensity [0] + each_top_selected_intensity [0]),4)
            top_n_spectra_sum_intensity [1]= round((top_n_spectra_sum_intensity [1] + each_top_selected_intensity [1]),4)
            top_n_spectra_sum_intensity [2]= round((top_n_spectra_sum_intensity [2] + each_top_selected_intensity [2]),4)
            ###top_n_spectra_sum_intensity [3]= round((top_n_spectra_sum_intensity [3] + each_top_selected_intensity [3]),4)

        if sum(top_n_spectra_sum_intensity) != 0:
            normalized_ratio_on_peptide_level = [round ((top_n_spectra_sum_intensity [0]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2),round ((top_n_spectra_sum_intensity [1]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2),round ((top_n_spectra_sum_intensity [2]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_peptide_level = [0,0,0]
               
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,top_n_spectra_sum_intensity)
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,normalized_ratio_on_peptide_level)
    ###print (all_intensity_collection_peptide_level)
    write_by_rows = [['peptide','all_related_scan_num','nor_pep_ra_+0','nor_pep_ra_+1','nor_pep_ra_+2','inten_+0','inten_+1','inten_+2','total_inten_all_cha','peptide_mass','protein(groups)_accession']]

    for each_peptide_seq in list (all_intensity_collection_peptide_level.keys()):
        
        if 0 in all_intensity_collection_peptide_level[each_peptide_seq][0]:
            continue
    
        new_line = [str (each_peptide_seq)]
        
        counted_scan_num = []
        for each_key in all_intensity_collection_peptide_level[each_peptide_seq] [3].keys():
            ###print (each_key)
            counted_scan_num.append (each_key)
        new_line.append (str (counted_scan_num))
            
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][2]))
        
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][2]))
        
        new_line.append (str (sum (all_intensity_collection_peptide_level[each_peptide_seq][1])))
        
        ###print ('str (all_intensity_collection_peptide_level[each_peptide_seq][-2:-1][0][1][3][1]')
        ###print (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1])
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][9][1]))
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Peptide_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Peptide_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    ########################################################################################################################## Calculating ratios on peptide level

    top_n_peptide_for_protein_ratio = int(input ('please indicates top N peptide used for protein ratio'))
    all_intensity_collection_protein_level = {}
    all_protein_protein_groups_collection = []
    
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        
        
        temp_protein_protein_groups = all_intensity_collection_peptide_level[each_peptide_seq][4][1][9][1]
        
        if temp_protein_protein_groups not in all_protein_protein_groups_collection and all_intensity_collection_peptide_level[each_peptide_seq][0] != []:
            all_protein_protein_groups_collection.append (temp_protein_protein_groups)
            all_intensity_collection_protein_level [temp_protein_protein_groups] = []

            all_intensity_collection_protein_level [temp_protein_protein_groups].append([all_intensity_collection_peptide_level[each_peptide_seq][1]])
            all_intensity_collection_protein_level [temp_protein_protein_groups].append ({each_peptide_seq:all_intensity_collection_peptide_level[each_peptide_seq][1]})
            all_intensity_collection_protein_level [temp_protein_protein_groups].append (all_intensity_collection_peptide_level[each_peptide_seq][4])
        else:
            if all_intensity_collection_protein_level [temp_protein_protein_groups] != []:
                all_intensity_collection_protein_level [temp_protein_protein_groups][0].append(all_intensity_collection_peptide_level[each_peptide_seq][1])
                all_intensity_collection_protein_level [temp_protein_protein_groups][1][each_peptide_seq] = all_intensity_collection_peptide_level[each_peptide_seq][1]

    ###print (all_intensity_collection_protein_level)
    print ('len (all_intensity_collection_protein_level', len (all_intensity_collection_protein_level))           
    import heapq
    
    empty_protein_protein_groups = []
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():
        ###print (all_intensity_collection_peptide_level [each_peptide_seq])
        if all_intensity_collection_protein_level [each_protein_protein_groups] == []:
            empty_protein_protein_groups.append (each_protein_protein_groups)
    for each_protein_protein_groups in empty_protein_protein_groups:
        
        del all_intensity_collection_protein_level [each_protein_protein_groups]
       
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():    
        all_intensity_collection_protein_level [each_protein_protein_groups][0] =heapq.nlargest(top_n_spectrum_for_peptide_ratio,all_intensity_collection_protein_level [each_protein_protein_groups][0])
    
    
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():
        
        top_n_peptide_sum_intensity = [0,0,0]
        for each_top_selected_protein_protein_groups in all_intensity_collection_protein_level [each_protein_protein_groups][0]:
            
            top_n_peptide_sum_intensity [0]= round((top_n_peptide_sum_intensity [0] + each_top_selected_protein_protein_groups [0]),4)
            top_n_peptide_sum_intensity [1]= round((top_n_peptide_sum_intensity [1] + each_top_selected_protein_protein_groups [1]),4)
            top_n_peptide_sum_intensity [2]= round((top_n_peptide_sum_intensity [2] + each_top_selected_protein_protein_groups [2]),4)
            ###top_n_spectra_sum_intensity [3]= round((top_n_spectra_sum_intensity [3] + each_top_selected_intensity [3]),4)

        if sum(top_n_peptide_sum_intensity) != 0:
            normalized_ratio_on_protein_level = [round ((top_n_peptide_sum_intensity [0]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [1]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [2]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_protein_level = [0,0,0]
               
        all_intensity_collection_protein_level [each_protein_protein_groups].insert (0,top_n_peptide_sum_intensity)
        all_intensity_collection_protein_level [each_protein_protein_groups].insert (0,normalized_ratio_on_protein_level)

    print ('len (all_intensity_collection_protein_level', len (all_intensity_collection_protein_level))
    write_by_rows = [['protein(groups)_accession','related_peptides','nor_pep_ra_+0','nor_pep_ra_+1','nor_pep_ra_+2','inten_+0','inten_+1','inten_+2','total_inten_all_cha']]

    for each_protein_protein_groups in list (all_intensity_collection_protein_level.keys()):
        
        if 0 in all_intensity_collection_protein_level[each_protein_protein_groups][0]:
            continue
    
        new_line = [str (each_protein_protein_groups)]
        
        related_peptides = []
        for each_key in all_intensity_collection_protein_level[each_protein_protein_groups][3].keys():
            ###print (each_key)
            related_peptides.append (each_key)
        new_line.append (str (related_peptides))
            
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][1]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][2]))
        
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][1]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][2]))
        
        new_line.append (str (sum (all_intensity_collection_protein_level[each_protein_protein_groups][1])))
        
        ###print ('str (all_intensity_collection_peptide_level[each_peptide_seq][-2:-1][0][1][3][1]')
        ###print (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1])
        ###new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1]))
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Protein_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Protein_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    return gather_quantification_ratio_for_all_scan_number

'''test_dict = {6302: [['b1_13C+0', 'S', 349.0705, 1902503.625], ['b1_13C+1', 'S', 350.0739, 1562874.25], ['b1_13C+2', 'S', 351.0773, 753759.8125], ['b1_13C+3', 'S', 352.0807, 1368160.25], ['b2_13C+0', 'SE', 478.1131, 923492.0625], ['b2_13C+1', 'SE', 479.1165, 1314714.25], ['b2_13C+2', 'SE', 480.1199, 995121.625], ['b2_13C+3', 'SE', 481.1233, 845429.625], ['b3_13C+0', 'SEI', 591.1945, '0'], ['b3_13C+1', 'SEI', 592.1979, '0'], ['b3_13C+2', 'SEI', 593.2013, '0'], ['b3_13C+3', 'SEI', 594.2047, '0'], ['b4_13C+0', 'SEIA', 662.2316, '0'], ['b4_13C+1', 'SEIA', 663.235, '0'], ['b4_13C+2', 'SEIA', 664.2384, '0'], ['b4_13C+3', 'SEIA', 665.2418, '0'], ['b5_13C+0', 'SEIAH', 799.2905, '0'], ['b5_13C+1', 'SEIAH', 800.2939, '0'], ['b5_13C+2', 'SEIAH', 801.2973, '0'], ['b5_13C+3', 'SEIAH', 802.3007, '0'], ['b6_13C+0', 'SEIAHR', 955.3916, 240325.2031], ['b6_13C+1', 'SEIAHR', 956.395, 265952.5312], ['b6_13C+2', 'SEIAHR', 957.3984, '0'], ['b6_13C+3', 'SEIAHR', 958.4018, 308347.6562], ['b7_13C+0', 'SEIAHRF', 1102.46, '0'], ['b7_13C+1', 'SEIAHRF', 1103.4634, '0'], ['b7_13C+2', 'SEIAHRF', 1104.4668, '0'], ['b7_13C+3', 'SEIAHRF', 1105.4702, '0'], ['b1_-H2O_13C+0', 'S', 331.0599, 1554115.75], ['b1_-H2O_13C+1', 'S', 332.0633, 1185224.5], ['b1_-H2O_13C+2', 'S', 333.0667, 1092276.0], ['b1_-H2O_13C+3', 'S', 334.0701, 1082826.0], ['b1_-NH3_13C+0', 'S', 332.044, 1185224.5], ['b1_-NH3_13C+1', 'S', 333.0474, 1092276.0], ['b1_-NH3_13C+2', 'S', 334.0508, 1082826.0], ['b1_-NH3_13C+3', 'S', 335.0542, '0'], ['b2_-H2O_13C+0', 'SE', 460.1025, 1563130.625], ['b2_-H2O_13C+1', 'SE', 461.1059, 2031038.375], ['b2_-H2O_13C+2', 'SE', 462.1093, 1456113.5], ['b2_-H2O_13C+3', 'SE', 463.1127, 1470833.125], ['b2_-NH3_13C+0', 'SE', 461.0866, 2031038.375], ['b2_-NH3_13C+1', 'SE', 462.09, 1456113.5], ['b2_-NH3_13C+2', 'SE', 463.0934, 1470833.125], ['b2_-NH3_13C+3', 'SE', 464.0968, '0'], ['b3_-H2O_13C+0', 'SEI', 573.1839, '0'], ['b3_-H2O_13C+1', 'SEI', 574.1873, '0'], ['b3_-H2O_13C+2', 'SEI', 575.1907, '0'], ['b3_-H2O_13C+3', 'SEI', 576.1941, '0'], ['b3_-NH3_13C+0', 'SEI', 574.168, '0'], ['b3_-NH3_13C+1', 'SEI', 575.1714, '0'], ['b3_-NH3_13C+2', 'SEI', 576.1748, '0'], ['b3_-NH3_13C+3', 'SEI', 577.1782, '0'], ['b4_-H2O_13C+0', 'SEIA', 644.221, '0'], ['b4_-H2O_13C+1', 'SEIA', 645.2244, '0'], ['b4_-H2O_13C+2', 'SEIA', 646.2278, '0'], ['b4_-H2O_13C+3', 'SEIA', 647.2312, '0'], ['b4_-NH3_13C+0', 'SEIA', 645.2051, '0'], ['b4_-NH3_13C+1', 'SEIA', 646.2085, '0'], ['b4_-NH3_13C+2', 'SEIA', 647.2119, '0'], ['b4_-NH3_13C+3', 'SEIA', 648.2153, '0'], ['b5_-H2O_13C+0', 'SEIAH', 781.2799, '0'], ['b5_-H2O_13C+1', 'SEIAH', 782.2833, '0'], ['b5_-H2O_13C+2', 'SEIAH', 783.2867, '0'], ['b5_-H2O_13C+3', 'SEIAH', 784.2901, '0'], ['b5_-NH3_13C+0', 'SEIAH', 782.264, '0'], ['b5_-NH3_13C+1', 'SEIAH', 783.2674, '0'], ['b5_-NH3_13C+2', 'SEIAH', 784.2708, '0'], ['b5_-NH3_13C+3', 'SEIAH', 785.2742, '0'], ['b6_-H2O_13C+0', 'SEIAHR', 937.381, '0'], ['b6_-H2O_13C+1', 'SEIAHR', 938.3844, '0'], ['b6_-H2O_13C+2', 'SEIAHR', 939.3878, '0'], ['b6_-H2O_13C+3', 'SEIAHR', 940.3912, '0'], ['b6_-NH3_13C+0', 'SEIAHR', 938.3651, '0'], ['b6_-NH3_13C+1', 'SEIAHR', 939.3685, '0'], ['b6_-NH3_13C+2', 'SEIAHR', 940.3719, '0'], ['b6_-NH3_13C+3', 'SEIAHR', 941.3753, '0'], ['b7_-H2O_13C+0', 'SEIAHRF', 1084.4494, '0'], ['b7_-H2O_13C+1', 'SEIAHRF', 1085.4528, '0'], ['b7_-H2O_13C+2', 'SEIAHRF', 1086.4562, '0'], ['b7_-H2O_13C+3', 'SEIAHRF', 1087.4596, '0'], ['b7_-NH3_13C+0', 'SEIAHRF', 1085.4335, '0'], ['b7_-NH3_13C+1', 'SEIAHRF', 1086.4369, '0'], ['b7_-NH3_13C+2', 'SEIAHRF', 1087.4403, '0'], ['b7_-NH3_13C+3', 'SEIAHRF', 1088.4437, '0'], ['y1_13C+0', 'K', 260.161, 589575.25], ['y1_13C+1', 'K', 261.1644, 304855.3125], ['y1_13C+2', 'K', 262.1678, 558615.875], ['y1_13C+3', 'K', 263.1712, 303316.7188], ['y2_13C+0', 'KF', 407.2294, 624678.125], ['y2_13C+1', 'KF', 408.2328, 349911.875], ['y2_13C+2', 'KF', 409.2362, 677629.625], ['y2_13C+3', 'KF', 410.2396, 849589.8125], ['y3_13C+0', 'KFR', 563.3305, 1533017.5], ['y3_13C+1', 'KFR', 564.3339, 1507670.75], ['y3_13C+2', 'KFR', 565.3373, 1972881.875], ['y3_13C+3', 'KFR', 566.3407, 1339827.5], ['y4_13C+0', 'KFRH', 700.3894, 3417394.5], ['y4_13C+1', 'KFRH', 701.3928, 2721766.25], ['y4_13C+2', 'KFRH', 702.3962, 3689109.0], ['y4_13C+3', 'KFRH', 703.3996, 3383925.5], ['y5_13C+0', 'KFRHA', 771.4265, 5251915.0], ['y5_13C+1', 'KFRHA', 772.4299, 5554512.5], ['y5_13C+2', 'KFRHA', 773.4333, 6313523.0], ['y5_13C+3', 'KFRHA', 774.4367, 6475699.5], ['y6_13C+0', 'KFRHAI', 884.5079, 1271257.375], ['y6_13C+1', 'KFRHAI', 885.5113, 1481627.875], ['y6_13C+2', 'KFRHAI', 886.5147, 2040247.875], ['y6_13C+3', 'KFRHAI', 887.5181, 2084363.25], ['y7_13C+0', 'KFRHAIE', 1013.5505, 949708.1875], ['y7_13C+1', 'KFRHAIE', 1014.5539, 946727.9375], ['y7_13C+2', 'KFRHAIE', 1015.5573, 835570.9375], ['y7_13C+3', 'KFRHAIE', 1016.5607, 1060332.625], ['y1_-H2O_13C+0', 'K', 242.1504, '0'], ['y1_-H2O_13C+1', 'K', 243.1538, 274019.5938], ['y1_-H2O_13C+2', 'K', 244.1572, '0'], ['y1_-H2O_13C+3', 'K', 245.1606, '0'], ['y1_-NH3_13C+0', 'K', 243.1345, 274019.5938], ['y1_-NH3_13C+1', 'K', 244.1379, '0'], ['y1_-NH3_13C+2', 'K', 245.1413, '0'], ['y1_-NH3_13C+3', 'K', 246.1447, '0'], ['y2_-H2O_13C+0', 'KF', 389.2188, '0'], ['y2_-H2O_13C+1', 'KF', 390.2222, '0'], ['y2_-H2O_13C+2', 'KF', 391.2256, '0'], ['y2_-H2O_13C+3', 'KF', 392.229, '0'], ['y2_-NH3_13C+0', 'KF', 390.2029, '0'], ['y2_-NH3_13C+1', 'KF', 391.2063, '0'], ['y2_-NH3_13C+2', 'KF', 392.2097, '0'], ['y2_-NH3_13C+3', 'KF', 393.2131, '0'], ['y3_-H2O_13C+0', 'KFR', 545.3199, '0'], ['y3_-H2O_13C+1', 'KFR', 546.3233, '0'], ['y3_-H2O_13C+2', 'KFR', 547.3267, '0'], ['y3_-H2O_13C+3', 'KFR', 548.3301, '0'], ['y3_-NH3_13C+0', 'KFR', 546.304, '0'], ['y3_-NH3_13C+1', 'KFR', 547.3074, '0'], ['y3_-NH3_13C+2', 'KFR', 548.3108, '0'], ['y3_-NH3_13C+3', 'KFR', 549.3142, '0'], ['y4_-H2O_13C+0', 'KFRH', 682.3788, '0'], ['y4_-H2O_13C+1', 'KFRH', 683.3822, 173730.7969], ['y4_-H2O_13C+2', 'KFRH', 684.3856, '0'], ['y4_-H2O_13C+3', 'KFRH', 685.389, '0'], ['y4_-NH3_13C+0', 'KFRH', 683.3629, 173730.7969], ['y4_-NH3_13C+1', 'KFRH', 684.3663, '0'], ['y4_-NH3_13C+2', 'KFRH', 685.3697, '0'], ['y4_-NH3_13C+3', 'KFRH', 686.3731, '0'], ['y4_2charge_13C+0', 'KFRH', 351.2025, 184259.4219], ['y4_2charge_13C+1', 'KFRH', 352.2059, 897756.875], ['y4_2charge_13C+2', 'KFRH', 353.2093, '0'], ['y4_2charge_13C+3', 'KFRH', 354.2127, '0'], ['y5_-H2O_13C+0', 'KFRHA', 753.4159, '0'], ['y5_-H2O_13C+1', 'KFRHA', 754.4193, '0'], ['y5_-H2O_13C+2', 'KFRHA', 755.4227, 286368.1562], ['y5_-H2O_13C+3', 'KFRHA', 756.4261, '0'], ['y5_-NH3_13C+0', 'KFRHA', 754.4, '0'], ['y5_-NH3_13C+1', 'KFRHA', 755.4034, 286368.1562], ['y5_-NH3_13C+2', 'KFRHA', 756.4068, '0'], ['y5_-NH3_13C+3', 'KFRHA', 757.4102, '0'], ['y5_2charge_13C+0', 'KFRHA', 386.721, 527228.9375], ['y5_2charge_13C+1', 'KFRHA', 387.7244, '0'], ['y5_2charge_13C+2', 'KFRHA', 388.7278, '0'], ['y5_2charge_13C+3', 'KFRHA', 389.7312, '0'], ['y6_-H2O_13C+0', 'KFRHAI', 866.4973, '0'], ['y6_-H2O_13C+1', 'KFRHAI', 867.5007, '0'], ['y6_-H2O_13C+2', 'KFRHAI', 868.5041, '0'], ['y6_-H2O_13C+3', 'KFRHAI', 869.5075, '0'], ['y6_-NH3_13C+0', 'KFRHAI', 867.4814, '0'], ['y6_-NH3_13C+1', 'KFRHAI', 868.4848, '0'], ['y6_-NH3_13C+2', 'KFRHAI', 869.4882, '0'], ['y6_-NH3_13C+3', 'KFRHAI', 870.4916, '0'], ['y6_2charge_13C+0', 'KFRHAI', 443.2618, 311066.1875], ['y6_2charge_13C+1', 'KFRHAI', 444.2652, 626713.6875], ['y6_2charge_13C+2', 'KFRHAI', 445.2686, '0'], ['y6_2charge_13C+3', 'KFRHAI', 446.272, '0'], ['y7_-H2O_13C+0', 'KFRHAIE', 995.5399, '0'], ['y7_-H2O_13C+1', 'KFRHAIE', 996.5433, '0'], ['y7_-H2O_13C+2', 'KFRHAIE', 997.5467, '0'], ['y7_-H2O_13C+3', 'KFRHAIE', 998.5501, 211476.4062], ['y7_-NH3_13C+0', 'KFRHAIE', 996.524, '0'], ['y7_-NH3_13C+1', 'KFRHAIE', 997.5274, '0'], ['y7_-NH3_13C+2', 'KFRHAIE', 998.5308, 211476.4062], ['y7_-NH3_13C+3', 'KFRHAIE', 999.5342, '0'], ['y7_2charge_13C+0', 'KFRHAIE', 507.7831, 353702.7188], ['y7_2charge_13C+1', 'KFRHAIE', 508.7865, 187330.3594], ['y7_2charge_13C+2', 'KFRHAIE', 509.7899, '0'], ['y7_2charge_13C+3', 'KFRHAIE', 510.7933, '0'], ['spectrum_information', [['m_over_z', 682.8141], ['retention_time', 1807.2], ['peptide', 'SEIAHRFK'], ['mass', 1363.6183], ['charge_states', 2], ['logP', 36.75], ['length', 8], ['ppm', -3.4], ['area', '9.4865E8'], ['protein_accession', 'P02769'], ['determining_precursor_selection', 1]]]]}
test_dict_large_peptide ={'1734.27354':[['b1', 'S', 116.0711, '0'], ['b2', 'SE', 245.1137, 11881.1], ['b3', 'SEI', 358.1951, 5838.0], ['b4', 'SEIA', 429.2322, 1736.5], ['b5', 'SEIAH', 566.2911, '0'], ['b6', 'SEIAHR', 722.3922, '0'], ['b7', 'SEIAHRF', 869.4606, '0'], ['b1_-H2O', 'S', 98.0605, '0'], ['b1_-NH3', 'S', 99.0446, '0'], ['b2_-H2O', 'SE', 227.1031, '0'], ['b2_-NH3', 'SE', 228.0872, '0'], ['b3_-H2O', 'SEI', 340.1845, '0'], ['b3_-NH3', 'SEI', 341.1686, '0'], ['b4_-H2O', 'SEIA', 411.2216, '0'], ['b4_-NH3', 'SEIA', 412.2057, '0'], ['b5_-H2O', 'SEIAH', 548.2805, '0'], ['b5_-NH3', 'SEIAH', 549.2646, '0'], ['b6_-H2O', 'SEIAHR', 704.3816, '0'], ['b6_-NH3', 'SEIAHR', 705.3657, '0'], ['b7_-H2O', 'SEIAHRF', 851.45, '0'], ['b7_-NH3', 'SEIAHRF', 852.4341, '0'], ['y1_13C+0', 'K', 301.1875, '0'], ['y1_13C+1', 'K', 302.1909, '0'], ['y1_13C+2', 'K', 303.1943, '0'], ['y2_13C+0', 'FK', 448.2559, '0'], ['y2_13C+1', 'FK', 449.2593, '0'], ['y2_13C+2', 'FK', 450.2627, '0'], ['y3_13C+0', 'RFK', 604.357, '0'], ['y3_13C+1', 'RFK', 605.3604, '0'], ['y3_13C+2', 'RFK', 606.3638, '0'], ['y4_13C+0', 'HRFK', 741.4159, 2923.6], ['y4_13C+1', 'HRFK', 742.4193, 3320.7], ['y4_13C+2', 'HRFK', 743.4227, 2604.6], ['y5_13C+0', 'AHRFK', 812.453, 2678.6], ['y5_13C+1', 'AHRFK', 813.4564, 3183.4], ['y5_13C+2', 'AHRFK', 814.4598, 7245.4], ['y6_13C+0', 'IAHRFK', 925.5344, 3611.7], ['y6_13C+1', 'IAHRFK', 926.5378, 3840.5], ['y6_13C+2', 'IAHRFK', 927.5412, 3007.2], ['y7_13C+0', 'EIAHRFK', 1054.577, 10002.2], ['y7_13C+1', 'EIAHRFK', 1055.5804, 12959.2], ['y7_13C+2', 'EIAHRFK', 1056.5838, 10919.7], ['y8_13C+0', 'SEIAHRFK', 1169.6403, '0'], ['y8_13C+1', 'SEIAHRFK', 1170.6437, '0'], ['y8_13C+2', 'SEIAHRFK', 1171.6471, '0'], ['y1_-H2O_13C+0', 'K', 283.1769, '0'], ['y1_-H2O_13C+1', 'K', 284.1803, '0'], ['y1_-H2O_13C+2', 'K', 285.1837, '0'], ['y1_-NH3_13C+0', 'K', 284.161, '0'], ['y1_-NH3_13C+1', 'K', 285.1644, '0'], ['y1_-NH3_13C+2', 'K', 286.1678, '0'], ['y2_-H2O_13C+0', 'FK', 430.2453, '0'], ['y2_-H2O_13C+1', 'FK', 431.2487, '0'], ['y2_-H2O_13C+2', 'FK', 432.2521, '0'], ['y2_-NH3_13C+0', 'FK', 431.2294, '0'], ['y2_-NH3_13C+1', 'FK', 432.2328, '0'], ['y2_-NH3_13C+2', 'FK', 433.2362, '0'], ['y3_-H2O_13C+0', 'RFK', 586.3464, 14544.6], ['y3_-H2O_13C+1', 'RFK', 587.3498, '0'], ['y3_-H2O_13C+2', 'RFK', 588.3532, '0'], ['y3_-NH3_13C+0', 'RFK', 587.3305, '0'], ['y3_-NH3_13C+1', 'RFK', 588.3339, '0'], ['y3_-NH3_13C+2', 'RFK', 589.3373, '0'], ['y4_-H2O_13C+0', 'HRFK', 723.4053, '0'], ['y4_-H2O_13C+1', 'HRFK', 724.4087, '0'], ['y4_-H2O_13C+2', 'HRFK', 725.4121, '0'], ['y4_-NH3_13C+0', 'HRFK', 724.3894, '0'], ['y4_-NH3_13C+1', 'HRFK', 725.3928, '0'], ['y4_-NH3_13C+2', 'HRFK', 726.3962, '0'], ['y4_2charge_13C+0', 'HRFK', 371.2118, '0'], ['y4_2charge_13C+1', 'HRFK', 371.7135, '0'], ['y4_2charge_13C+2', 'HRFK', 372.2152, '0'], ['y5_-H2O_13C+0', 'AHRFK', 794.4424, '0'], ['y5_-H2O_13C+1', 'AHRFK', 795.4458, '0'], ['y5_-H2O_13C+2', 'AHRFK', 796.4492, '0'], ['y5_-NH3_13C+0', 'AHRFK', 795.4265, '0'], ['y5_-NH3_13C+1', 'AHRFK', 796.4299, '0'], ['y5_-NH3_13C+2', 'AHRFK', 797.4333, '0'], ['y5_2charge_13C+0', 'AHRFK', 406.7304, '0'], ['y5_2charge_13C+1', 'AHRFK', 407.2321, '0'], ['y5_2charge_13C+2', 'AHRFK', 407.7338, '0'], ['y6_-H2O_13C+0', 'IAHRFK', 907.5238, '0'], ['y6_-H2O_13C+1', 'IAHRFK', 908.5272, '0'], ['y6_-H2O_13C+2', 'IAHRFK', 909.5306, '0'], ['y6_-NH3_13C+0', 'IAHRFK', 908.5079, '0'], ['y6_-NH3_13C+1', 'IAHRFK', 909.5113, '0'], ['y6_-NH3_13C+2', 'IAHRFK', 910.5147, '0'], ['y6_2charge_13C+0', 'IAHRFK', 463.2711, '0'], ['y6_2charge_13C+1', 'IAHRFK', 463.7728, '0'], ['y6_2charge_13C+2', 'IAHRFK', 464.2745, '0'], ['y7_-H2O_13C+0', 'EIAHRFK', 1036.5664, '0'], ['y7_-H2O_13C+1', 'EIAHRFK', 1037.5698, '0'], ['y7_-H2O_13C+2', 'EIAHRFK', 1038.5732, '0'], ['y7_-NH3_13C+0', 'EIAHRFK', 1037.5505, '0'], ['y7_-NH3_13C+1', 'EIAHRFK', 1038.5539, '0'], ['y7_-NH3_13C+2', 'EIAHRFK', 1039.5573, '0'], ['y7_2charge_13C+0', 'EIAHRFK', 527.7924, '0'], ['y7_2charge_13C+1', 'EIAHRFK', 528.2941, '0'], ['y7_2charge_13C+2', 'EIAHRFK', 528.7958, '0'], ['y8_-H2O_13C+0', 'SEIAHRFK', 1151.6297, '0'], ['y8_-H2O_13C+1', 'SEIAHRFK', 1152.6331, '0'], ['y8_-H2O_13C+2', 'SEIAHRFK', 1153.6365, '0'], ['y8_-NH3_13C+0', 'SEIAHRFK', 1152.6138, '0'], ['y8_-NH3_13C+1', 'SEIAHRFK', 1153.6172, '0'], ['y8_-NH3_13C+2', 'SEIAHRFK', 1154.6206, '0'], ['y8_2charge_13C+0', 'SEIAHRFK', 585.3241, 13170.9], ['y8_2charge_13C+1', 'SEIAHRFK', 585.8258, 11758.4], ['y8_2charge_13C+2', 'SEIAHRFK', 586.3275, 14544.6], ['spectrum_information', [['m_over_z', 663.874], ['peptide', 'SEIAHRFK'], ['mass', 1325.7366], ['charge_states', '2+'], ['localization_confidence', 'Ac-Ile(+0)-Pro-Gly(+2) (8: Very Confident)'], ['ppm', -2.3783], ['protein_accession', 'P02769'], ['determining_precursor_selection', 1]]]]}
working_path = 'G:\\Desktop\\NAPI-tag\\Scripts for Ac-IPG tag\\'

simpilified_test_dict = normalize_ratio_for_spec (working_path,test_dict_large_peptide)'''
