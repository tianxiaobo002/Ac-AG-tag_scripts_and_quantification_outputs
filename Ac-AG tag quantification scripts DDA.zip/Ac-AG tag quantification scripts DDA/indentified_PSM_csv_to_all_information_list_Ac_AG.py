def extract_PSMs_and_return_all_theoretial_ions (all_unique_peptides = 1,*file_route_and_file_name):

    import csv
#importing csv module
    import re
#importing re module for removing the numbers in row of .csv file

    space = ''
    cvs_every_spectrum = {}
    scan_num_collection = []
    
    for each_DB_search_psm_csv_file in file_route_and_file_name:
        file_route = each_DB_search_psm_csv_file [0]
        file_name = each_DB_search_psm_csv_file [1]

        '''print (all_unique_peptides)'''

        with open(file_route + file_name) as csvfile:
            reader = csv.DictReader(csvfile)
#calling the csv reader and read the target csv file
    
            for row in reader:
                spectrum_information = []
                scan_number = row['Scan']
                charge_states = int (row['Z'])
                if scan_number == '':
                    break
                ###remove the 3 charge peptide. some 13C contribution was found in the 3 charge spectrum
                elif charge_states != 2:
                    continue
                else:
                    scan_number = int (row['Scan'])
                    m_over_z = round (float (row['m/z']),4)
                    retention_time = round (float (row['RT'])*60,4)
                    peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))
                    mass = round (float (row['Mass']),4)
                    charge_states = int (row['Z'])
                    logP = round (float (row['-10lgP']),2)
                    length = int (row['Length'])
                    ppm = round (float (row['ppm']),1)
                    area = row['Area']
                    protein_accession = row['Accession']

                    if peptide in all_unique_peptides and scan_number not in scan_num_collection:
                    
                        pep_seq = peptide
                        import ion_produceor_Ac_AG_3channels
                        all_theoretial_ions = ion_produceor_Ac_AG_3channels.y_ion_type_name_mass_channels_name_mass_producor_single_quantification_ion(pep_seq)
                        #print (all_theoretial_ions)
                        
                        spectrum_information.append (['m_over_z',m_over_z])
                        spectrum_information.append (['retention_time',retention_time])
                        spectrum_information.append (['peptide',peptide])
                        spectrum_information.append (['mass',mass])
                        spectrum_information.append (['charge_states',charge_states])
                        spectrum_information.append (['logP',logP])
                        spectrum_information.append (['length',length])
                        spectrum_information.append (['ppm',ppm])
                        spectrum_information.append (['area',area])
                        spectrum_information.append (['protein_accession',protein_accession])
                        all_theoretial_ions.append (['spectrum_information',spectrum_information])
                        cvs_every_spectrum [scan_number] = all_theoretial_ions
                        scan_num_collection.append (scan_number)
                        
            
    
    output_file = open (file_route + 'Dict_all_quantification_ions_test.txt', 'w')
    output_file.write(str(cvs_every_spectrum))
    output_file.close()

    return cvs_every_spectrum

'''file_path ='G:\\Desktop\\IPTL\\4-plex labeling quantification scripts\\Under writing\\'
test_file_1 = 'DB search psm - 1-20.csv'
test_file_2 = 'DB search psm - 21-40.csv'
test_file_3 = 'DB search psm - 41-60.csv'
test_file_4 = 'DB search psm - 61-74.csv'

all_uni_peps = extract_PSMs_and_return_all_theoretial_ions ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3],[file_path,test_file_4])'''



        

       
