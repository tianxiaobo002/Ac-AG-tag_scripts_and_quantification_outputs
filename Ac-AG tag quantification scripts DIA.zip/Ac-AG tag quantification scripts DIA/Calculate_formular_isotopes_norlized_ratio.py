from pyopenms import *
def formula_calculation (pep_seq):
    single_aa_CHONS = {'A':[['Carbon',3],['Hydrogen',5],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],'R':[['Carbon',6],['Hydrogen',12],['Nitrogen',4],['Oxygen',1],['Sulfur',0]],\
                   'N':[['Carbon',4],['Hydrogen',6],['Nitrogen',2],['Oxygen',2],['Sulfur',0]],'D':[['Carbon',4],['Hydrogen',5],['Nitrogen',1],['Oxygen',3],['Sulfur',0]],\
                   'C':[['Carbon',3],['Hydrogen',5],['Nitrogen',1],['Oxygen',1],['Sulfur',1]],'Q':[['Carbon',5],['Hydrogen',8],['Nitrogen',2],['Oxygen',2],['Sulfur',0]],\
                   'E':[['Carbon',5],['Hydrogen',7],['Nitrogen',1],['Oxygen',3],['Sulfur',0]],'G':[['Carbon',2],['Hydrogen',3],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],\
                   'H':[['Carbon',6],['Hydrogen',7],['Nitrogen',3],['Oxygen',1],['Sulfur',0]],'I':[['Carbon',6],['Hydrogen',11],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],\
                   'L':[['Carbon',6],['Hydrogen',11],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],'K':[['Carbon',6],['Hydrogen',12],['Nitrogen',2],['Oxygen',1],['Sulfur',0]],\
                   'M':[['Carbon',5],['Hydrogen',9],['Nitrogen',1],['Oxygen',1],['Sulfur',1]],'F':[['Carbon',9],['Hydrogen',9],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],\
                   'P':[['Carbon',5],['Hydrogen',7],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],'S':[['Carbon',3],['Hydrogen',5],['Nitrogen',1],['Oxygen',2],['Sulfur',0]],\
                   'T':[['Carbon',4],['Hydrogen',7],['Nitrogen',1],['Oxygen',2],['Sulfur',0]],'W':[['Carbon',11],['Hydrogen',10],['Nitrogen',2],['Oxygen',1],['Sulfur',0]],\
                   'Y':[['Carbon',9],['Hydrogen',9],['Nitrogen',1],['Oxygen',2],['Sulfur',0]],'V':[['Carbon',5],['Hydrogen',9],['Nitrogen',1],['Oxygen',1],['Sulfur',0]]}
    modification = {"H_hydrogen":[['Carbon',0],['Hydrogen',1],['Nitrogen',0],['Oxygen',0],['Sulfur',0]],"OH_hydroxy":[['Carbon',0],['Hydrogen',1],['Nitrogen',0],['Oxygen',1],['Sulfur',0]],\
                    "Oxidation_Met":[['Carbon',0],['Hydrogen',0],['Nitrogen',0],['Oxygen',1],['Sulfur',0]],"Carbamidomethylation":[['Carbon',2],['Hydrogen',3],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],\
                    "Dimeth_N_termi":[['Carbon',2],['Hydrogen',4],['Nitrogen',0],['Oxygen',0],['Sulfur',0]],"Ac_AG_3_plex_tag":[['Carbon',7],['Hydrogen',10],['Nitrogen',2],['Oxygen',3],['Sulfur',0]],\
                    "Gly":[['Carbon',2],['Hydrogen',3],['Nitrogen',1],['Oxygen',1],['Sulfur',0]],"Ac_Ile_Pro":[['Carbon',13],['Hydrogen',20],['Nitrogen',2],['Oxygen',3],['Sulfur',0]]}
    
    peptide_formula = [['Carbon',0],['Hydrogen',0],['Nitrogen',0],['Oxygen',0],['Sulfur',0]]
    isotope_shape = [0,0,0,0]
    
    for every_amino_acid in (pep_seq):
        peptide_formula [0][1] = peptide_formula [0][1] + single_aa_CHONS [every_amino_acid][0][1]
        peptide_formula [1][1] = peptide_formula [1][1] + single_aa_CHONS [every_amino_acid][1][1]
        peptide_formula [2][1] = peptide_formula [2][1] + single_aa_CHONS [every_amino_acid][2][1]
        peptide_formula [3][1] = peptide_formula [3][1] + single_aa_CHONS [every_amino_acid][3][1]
        peptide_formula [4][1] = peptide_formula [4][1] + single_aa_CHONS [every_amino_acid][4][1]
        if every_amino_acid == 'C':
            peptide_formula [0][1] = peptide_formula [0][1] + modification ['Carbamidomethylation'][0][1]
            peptide_formula [1][1] = peptide_formula [1][1] + modification ['Carbamidomethylation'][1][1]
            peptide_formula [2][1] = peptide_formula [2][1] + modification ['Carbamidomethylation'][2][1]
            peptide_formula [3][1] = peptide_formula [3][1] + modification ['Carbamidomethylation'][3][1]
            peptide_formula [4][1] = peptide_formula [4][1] + modification ['Carbamidomethylation'][4][1]
    
    peptide_formula [0][1] = peptide_formula [0][1] + modification ['Dimeth_N_termi'][0][1] + modification ['Gly'][0][1] + modification ['OH_hydroxy'][0][1]
    peptide_formula [1][1] = peptide_formula [1][1] + modification ['Dimeth_N_termi'][1][1] + modification ['Gly'][1][1] + modification ['OH_hydroxy'][1][1]
    peptide_formula [2][1] = peptide_formula [2][1] + modification ['Dimeth_N_termi'][2][1] + modification ['Gly'][2][1] + modification ['OH_hydroxy'][2][1]
    peptide_formula [3][1] = peptide_formula [3][1] + modification ['Dimeth_N_termi'][3][1] + modification ['Gly'][3][1] + modification ['OH_hydroxy'][3][1]
    peptide_formula [4][1] = peptide_formula [4][1] + modification ['Dimeth_N_termi'][4][1] + modification ['Gly'][4][1] + modification ['OH_hydroxy'][4][1]

    peptide_formula_text = ''
    for each_elment in peptide_formula:
        if each_elment[1]!= 0:
            peptide_formula_text = peptide_formula_text + str (each_elment[0][0]) + str (each_elment[1])
        
    return peptide_formula_text

def isotope_shape_calculation (pep_seq):
    ###from pyopenms import EmpiricalFormula, getIsotopeDistribution
    wm = EmpiricalFormula(pep_seq)
    isotopes = wm.getIsotopeDistribution( CoarseIsotopePatternGenerator(5) ) #####numer indicates how many peaks will be produced 
    isotope_peaks_ratios = []
    for iso in isotopes.getContainer():
        
        isotope_peaks_ratios.append ([round (iso.getMZ(),6),round (iso.getIntensity(),6)])
    normalized_isotope_peaks_ratios = []
    normalizer = isotope_peaks_ratios [0][1]
    for each_peak in isotope_peaks_ratios:
        normalized_isotope_peaks_ratios.append ([each_peak [0],round (each_peak [1]/normalizer,4)])
        
    return normalized_isotope_peaks_ratios
            
###sequence = 'GAVILFSTCMDENQRHKPYW'
###sequence = 'SHINVVVIGHVDSGK'
###sequence = 'GWLYRAK'
###sequence = 'SEIAHRFK'
###sequence = 'YNGVFQECCQAEDK'
from pyopenms import *
###sequence = 'GTDWLNAK'
###sequence = 'TIVWNGPPGVFEFEK'

def deconvolute_intensities_and_produce_normalized_spectrum_ration (peptide_sequence,quantification_peaks,normalize_number):
    ##### for 3-plex labelled sample Peak1:Peak2:Peak3 X:X*ratio1+Y:X*ratio2+Y*ratio1+Z. normalized_isotope_peaks_ratios [1], normalized_isotope_peaks_ratios [2], quantification peak (6 peaks) is required
    ##### normalized_isotope_peaks_ratios = [1,ratio1,ratio2,ratio3,ratio4,ratio5] for 3-plex ratio1 and ratio2 are needed.
    ##### quantification_peaks [peak1,peak2,peak3,peak4,peak5,peak6]
    generated_formula = formula_calculation (peptide_sequence)
    normalized_isotope_peaks_ratios = isotope_shape_calculation (generated_formula)

    channel_1 = quantification_peaks [0]
    channel_2 = quantification_peaks [1] - (channel_1 * normalized_isotope_peaks_ratios [1][1])
    channel_3 = quantification_peaks [2] - (channel_1 * normalized_isotope_peaks_ratios [2][1] + channel_2 * normalized_isotope_peaks_ratios [1][1])
    normalizer = (channel_1 + channel_2 + channel_3)/normalize_number
    corrected_intensity = [channel_1,channel_2,channel_3]
    normalzied_ratio = [round ((channel_1/normalizer),2),round ((channel_2/normalizer),2),round ((channel_3/normalizer),2)]
    sum_corrected_intensity = sum (corrected_intensity)

    return ([normalzied_ratio,corrected_intensity,sum_corrected_intensity])
  
    
    
    
    
'''sequence = 'GTDWLANK'
###quantification_peaks = [2.71*10**7,6.53*10**7,1.55*10**8]
quantification_peaks = [1.06*10**8,9.78*10**7,5.77*10**7]
normalizer = 8

quantification_result = deconvolute_intensities_and_produce_normalized_spectrum_ration (sequence,quantification_peaks,normalizer)'''






