import Extract_unique_peptides_return_uni_pep_list

file_path ='H:\\Ac-AG tag\\DIA scripts and analysis\\DIA result\\Ac-AG-BSA-1510-yeast-521-DIA\\'
test_file_1 = 'protein-peptides.csv'

unique_peptides = Extract_unique_peptides_return_uni_pep_list.extract_and_return_uni_pep_list ([file_path,test_file_1])

import indentified_PSM_csv_to_all_information_list_Ac_AG

test_file_1 = 'DB search psm.csv'

all_thero_fragment_ions = indentified_PSM_csv_to_all_information_list_Ac_AG.extract_PSMs_and_return_all_theoretial_ions (unique_peptides,[file_path,test_file_1])

import Converting_the_mgf_to_py_dict

test_file_1 = 'Ac-AG-BSA-1510-yeast-521-DIA.mgf'

raw_mgf_to_dict = Converting_the_mgf_to_py_dict.converting_raw_mgf_to_dict ([file_path,test_file_1])

import matching_theo_frag_ion_with_raw_mgf_peak_list

all_thero_fragment_ions_added_measured_intens = matching_theo_frag_ion_with_raw_mgf_peak_list.adding_measured_intensity_to_thero_frag_ions (file_path,all_thero_fragment_ions,raw_mgf_to_dict)

import calculate_normalized_fragment_ion_ratio_for_spec

all_spec_normalized_ratio_and_thero_fragment_ions_added_measured_intens = calculate_normalized_fragment_ion_ratio_for_spec.normalize_ratio_for_spec (file_path,all_thero_fragment_ions_added_measured_intens)


