def normalize_ratio_for_spec (work_path,fragment_ions_matched_intens):

    ###Based on the theroretical ratio, calculating the normalize numeber
    desired_ratio = input ('please indicattes the mixed sample ratio')
    normalize_number = 0
    for each_ratio_number in desired_ratio:
        normalize_number = normalize_number + int(each_ratio_number)

    ###For 3-plex labeled fragment ion, if any channel lost the signal, the one will be discarded. Here, defining the minimum number of macthed 3-plex labeled ion.
    ###If the spectrum has less matched 3-plex labeled, the spectrum will be marked as 'not counted'
    
    file_path = work_path
    
    gather_quantification_ratio_for_all_scan_number = {}

    for each_scan_number in fragment_ions_matched_intens.keys():
        
        gather_quantification_ratio_for_all_scan_number [each_scan_number] = []
        
        all_kinds_of_quantification_ions = []
        for each_kind_of_quantification_ion in fragment_ions_matched_intens [each_scan_number]:
            if each_kind_of_quantification_ion [0][:-2] not in all_kinds_of_quantification_ions and each_kind_of_quantification_ion [0] != 'spectrum_information':
                all_kinds_of_quantification_ions.append (each_kind_of_quantification_ion [0][:-2])
        ion_name_match_three_plex_intensity = {}
        for each_kind_of_quantification_ion in all_kinds_of_quantification_ions:
            ion_name_match_three_plex_intensity [each_kind_of_quantification_ion] = []
        for each_kind_of_quantification_ion in fragment_ions_matched_intens [each_scan_number]:
            if each_kind_of_quantification_ion [0] != 'spectrum_information':
                ion_name_match_three_plex_intensity [each_kind_of_quantification_ion [0][:-2]].append (each_kind_of_quantification_ion)
        collect_three_intensities = [0,0,0]
        sum_three_intensities_number = 0
        normalized_ratio = [0,0,0]
        for each_key in ion_name_match_three_plex_intensity:
            
            for each_quanti_ion in ion_name_match_three_plex_intensity [each_key]:
                    
                if each_quanti_ion [0][-2:] == '+0':
                    collect_three_intensities [0] = round(float (each_quanti_ion [3]),4)
                if each_quanti_ion [0][-2:] == '+1':
                    collect_three_intensities [1] = round(float (each_quanti_ion [3]),4)
                if each_quanti_ion [0][-2:] == '+2':
                    collect_three_intensities [2] = round(float (each_quanti_ion [3]),4)

            peptide_sequence_on_measuring = fragment_ions_matched_intens [each_scan_number][-1:][0][1][2][1]
            quantification_ion_on_measuring = collect_three_intensities
            normalizer_on_measuring = normalize_number

            import Calculate_formular_isotopes_norlized_ratio
            if 0 not in collect_three_intensities:
                normalzied_ratio_corrected_intensity_sum_corrected_intensity = Calculate_formular_isotopes_norlized_ratio.deconvolute_intensities_and_produce_normalized_spectrum_ration (peptide_sequence_on_measuring,quantification_ion_on_measuring,normalizer_on_measuring)
                
                ion_name_match_three_plex_intensity [each_key].insert (0,normalzied_ratio_corrected_intensity_sum_corrected_intensity[2])
                ion_name_match_three_plex_intensity [each_key].insert (0,normalzied_ratio_corrected_intensity_sum_corrected_intensity[1])
                ion_name_match_three_plex_intensity [each_key].insert (0,normalzied_ratio_corrected_intensity_sum_corrected_intensity[0])
            else:
                ion_name_match_three_plex_intensity [each_key].insert (0,[sum (collect_three_intensities)])
                ion_name_match_three_plex_intensity [each_key].insert (0,collect_three_intensities)
                ion_name_match_three_plex_intensity [each_key].insert (0,normalized_ratio)
                
            '''sum_three_intensities = sum (collect_three_intensities)
            sum_three_intensities_number = sum (collect_three_intensities)
            
            if sum_three_intensities != 0:
                normalized_ratio [0] = round(collect_three_intensities [0]/(sum_three_intensities/normalize_number),2)
                normalized_ratio [1] = round(collect_three_intensities [1]/(sum_three_intensities/normalize_number),2)
                normalized_ratio [2] = round(collect_three_intensities [2]/(sum_three_intensities/normalize_number),2)'''
                
                

            collect_three_intensities = [0,0,0]
            sum_three_intensities_number = []
            normalized_ratio = [0,0,0]
        need_to_be_removed_key = []
        
        for each_key in ion_name_match_three_plex_intensity:
            if 0 in ion_name_match_three_plex_intensity [each_key][1]:
                need_to_be_removed_key.append (each_key)
        '''if fragment_ions_matched_intens [each_scan_number][-1:][0][1][-1:][0][1] == 1:

            for each_key in ion_name_match_three_plex_intensity:
                if each_key not in need_to_be_removed_key and 'second'in each_key:
                    need_to_be_removed_key.append (each_key)
        else:

            for each_key in ion_name_match_three_plex_intensity:
                if each_key not in need_to_be_removed_key and 'second'not in each_key:
                    need_to_be_removed_key.append (each_key)'''
            
        for each_key in need_to_be_removed_key:
            del ion_name_match_three_plex_intensity [each_key]
                
        if len (ion_name_match_three_plex_intensity) >1:
            
            combined_name = ''
            combined_ratio = [0,0,0]
            combined_single_intensity = [0,0,0]
            combined_sum_intensity = 0

            for each_key in ion_name_match_three_plex_intensity:
                combined_name = combined_name + each_key
                
                combined_single_intensity [0] = combined_single_intensity [0] + ion_name_match_three_plex_intensity[each_key][1][0]
                combined_single_intensity [1] = combined_single_intensity [1] + ion_name_match_three_plex_intensity[each_key][1][1]
                combined_single_intensity [2] = combined_single_intensity [2] + ion_name_match_three_plex_intensity[each_key][1][2]
            combined_sum_intensity = sum (combined_single_intensity)
            if combined_sum_intensity != 0:
                combined_ratio [0] = round(combined_single_intensity [0]/(combined_sum_intensity/normalize_number),2)
                combined_ratio [1] = round(combined_single_intensity [1]/(combined_sum_intensity/normalize_number),2)
                combined_ratio [2] = round(combined_single_intensity [2]/(combined_sum_intensity/normalize_number),2)
                
            ion_name_match_three_plex_intensity.clear()
            ion_name_match_three_plex_intensity [str (combined_name)]= []
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_sum_intensity)
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_single_intensity)
            ion_name_match_three_plex_intensity [combined_name].insert (0,combined_ratio)
             
        gather_quantification_ratio_for_all_scan_number [each_scan_number].append (ion_name_match_three_plex_intensity)
        gather_quantification_ratio_for_all_scan_number [each_scan_number].append (fragment_ions_matched_intens [each_scan_number] [-1:])

    import csv

    write_by_rows = [['scan_number','quantification_name','normalized_ratio','nor_ra_+0','nor_ra_+1','nor_ra_+2','inten_+0','inten_+1','inten_+2','to_inten_3cha']]
    
    for scan_number in gather_quantification_ratio_for_all_scan_number.keys():
        
        
        new_line = [str (scan_number)]
        for each_key in gather_quantification_ratio_for_all_scan_number[scan_number][0]:
            new_line.append (str (each_key))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][0]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][1]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][0][2]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][0]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][1]))
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][1][2]))
            
            new_line.append (str (gather_quantification_ratio_for_all_scan_number[scan_number][0][each_key][2]))
        
        write_by_rows.append (new_line)
           
    output_file = open (file_path + 'Spectrum_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(output_file)
    print ('preparing Spectrum_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    ########################################################################################################################## Calculating ratios on peptide level

    top_n_spectrum_for_peptide_ratio = int(input ('please indicates top N spectrum used for peptide ratio'))
    all_intensity_collection_peptide_level = {}
    all_peptides_collection = []
    
    for scan_number in gather_quantification_ratio_for_all_scan_number.keys():
        
        ### the next step is to creat the intensities collection grouped by peptide sequence, the first item is the all 3-plex intensities collection which will be used to select top n
        ### the second item is the records of the specific spectrum, the third is the peptide information
        temp_peptide_sequence = gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1]
        
        if gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1] not in all_peptides_collection and gather_quantification_ratio_for_all_scan_number[scan_number][0] != []:
            all_peptides_collection.append (temp_peptide_sequence)
            all_intensity_collection_peptide_level [temp_peptide_sequence] = []

            for every_quantification_ion in gather_quantification_ratio_for_all_scan_number[scan_number][0]:

                
                ###print ('temp_peptide_sequence = gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0][1][2][1]',temp_peptide_sequence)
                ###print (gather_quantification_ratio_for_all_scan_number[scan_number][0])
                
                        
                all_intensity_collection_peptide_level [temp_peptide_sequence].append([gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]])
                all_intensity_collection_peptide_level [temp_peptide_sequence].append ({scan_number:gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]})
                all_intensity_collection_peptide_level [temp_peptide_sequence].append (gather_quantification_ratio_for_all_scan_number[scan_number][-1:][0][0])
        else:
            for every_quantification_ion in gather_quantification_ratio_for_all_scan_number[scan_number][0]:
                ###print ('gather_quantification_ratio_for_all_scan_number[scan_number][0]',gather_quantification_ratio_for_all_scan_number[scan_number][0])
                ###print ('repeated peptide sequence',all_intensity_collection_peptide_level [temp_peptide_sequence])
                if all_intensity_collection_peptide_level [temp_peptide_sequence] != []:
                    all_intensity_collection_peptide_level [temp_peptide_sequence][0].append(gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1])
                    all_intensity_collection_peptide_level [temp_peptide_sequence][1][scan_number] = gather_quantification_ratio_for_all_scan_number[scan_number][0][every_quantification_ion][1]
    
    ### the next is to find out the top n spectra
                
    import heapq
    empty_sequence = []
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        ###print (all_intensity_collection_peptide_level [each_peptide_seq])
        if all_intensity_collection_peptide_level [each_peptide_seq] == []:
            empty_sequence.append (each_peptide_seq)
    for each_empty_peptide_seq in empty_sequence:
        
        del all_intensity_collection_peptide_level [each_empty_peptide_seq]
       
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():    
        all_intensity_collection_peptide_level [each_peptide_seq][0] =heapq.nlargest(top_n_spectrum_for_peptide_ratio,all_intensity_collection_peptide_level [each_peptide_seq][0])
    
    
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        
        top_n_spectra_sum_intensity = [0,0,0]
        for each_top_selected_intensity in all_intensity_collection_peptide_level [each_peptide_seq][0]:
            
            top_n_spectra_sum_intensity [0]= round((top_n_spectra_sum_intensity [0] + each_top_selected_intensity [0]),4)
            top_n_spectra_sum_intensity [1]= round((top_n_spectra_sum_intensity [1] + each_top_selected_intensity [1]),4)
            top_n_spectra_sum_intensity [2]= round((top_n_spectra_sum_intensity [2] + each_top_selected_intensity [2]),4)
            ###top_n_spectra_sum_intensity [3]= round((top_n_spectra_sum_intensity [3] + each_top_selected_intensity [3]),4)

        if sum(top_n_spectra_sum_intensity) != 0:
            normalized_ratio_on_peptide_level = [round ((top_n_spectra_sum_intensity [0]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2),round ((top_n_spectra_sum_intensity [1]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2),round ((top_n_spectra_sum_intensity [2]/(sum(top_n_spectra_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_peptide_level = [0,0,0]
               
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,top_n_spectra_sum_intensity)
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,normalized_ratio_on_peptide_level)
    ###print (all_intensity_collection_peptide_level)
    write_by_rows = [['peptide','all_related_scan_num','nor_pep_ra_+0','nor_pep_ra_+1','nor_pep_ra_+2','inten_+0','inten_+1','inten_+2','total_inten_all_cha','peptide_mass','protein(groups)_accession']]

    for each_peptide_seq in list (all_intensity_collection_peptide_level.keys()):
        
        if 0 in all_intensity_collection_peptide_level[each_peptide_seq][0]:
            continue
    
        new_line = [str (each_peptide_seq)]
        
        counted_scan_num = []
        for each_key in all_intensity_collection_peptide_level[each_peptide_seq] [3].keys():
            ###print (each_key)
            counted_scan_num.append (each_key)
        new_line.append (str (counted_scan_num))
            
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][2]))
        
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1][2]))
        
        new_line.append (str (sum (all_intensity_collection_peptide_level[each_peptide_seq][1])))
        
        ###print ('str (all_intensity_collection_peptide_level[each_peptide_seq][-2:-1][0][1][3][1]')
        ###print (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1])
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][9][1]))
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Peptide_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Peptide_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    ########################################################################################################################## Calculating ratios on peptide level

    top_n_peptide_for_protein_ratio = int(input ('please indicates top N peptide used for protein ratio'))
    all_intensity_collection_protein_level = {}
    all_protein_protein_groups_collection = []
    
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        
        
        temp_protein_protein_groups = all_intensity_collection_peptide_level[each_peptide_seq][4][1][9][1]
        
        if temp_protein_protein_groups not in all_protein_protein_groups_collection and all_intensity_collection_peptide_level[each_peptide_seq][0] != []:
            all_protein_protein_groups_collection.append (temp_protein_protein_groups)
            all_intensity_collection_protein_level [temp_protein_protein_groups] = []

            all_intensity_collection_protein_level [temp_protein_protein_groups].append([all_intensity_collection_peptide_level[each_peptide_seq][1]])
            all_intensity_collection_protein_level [temp_protein_protein_groups].append ({each_peptide_seq:all_intensity_collection_peptide_level[each_peptide_seq][1]})
            all_intensity_collection_protein_level [temp_protein_protein_groups].append (all_intensity_collection_peptide_level[each_peptide_seq][4])
        else:
            if all_intensity_collection_protein_level [temp_protein_protein_groups] != []:
                all_intensity_collection_protein_level [temp_protein_protein_groups][0].append(all_intensity_collection_peptide_level[each_peptide_seq][1])
                all_intensity_collection_protein_level [temp_protein_protein_groups][1][each_peptide_seq] = all_intensity_collection_peptide_level[each_peptide_seq][1]

    ###print (all_intensity_collection_protein_level)
    print ('len (all_intensity_collection_protein_level', len (all_intensity_collection_protein_level))           
    import heapq
    
    empty_protein_protein_groups = []
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():
        ###print (all_intensity_collection_peptide_level [each_peptide_seq])
        if all_intensity_collection_protein_level [each_protein_protein_groups] == []:
            empty_protein_protein_groups.append (each_protein_protein_groups)
    for each_protein_protein_groups in empty_protein_protein_groups:
        
        del all_intensity_collection_protein_level [each_protein_protein_groups]
       
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():    
        all_intensity_collection_protein_level [each_protein_protein_groups][0] =heapq.nlargest(top_n_spectrum_for_peptide_ratio,all_intensity_collection_protein_level [each_protein_protein_groups][0])
    
    
    for each_protein_protein_groups in all_intensity_collection_protein_level.keys():
        
        top_n_peptide_sum_intensity = [0,0,0]
        for each_top_selected_protein_protein_groups in all_intensity_collection_protein_level [each_protein_protein_groups][0]:
            
            top_n_peptide_sum_intensity [0]= round((top_n_peptide_sum_intensity [0] + each_top_selected_protein_protein_groups [0]),4)
            top_n_peptide_sum_intensity [1]= round((top_n_peptide_sum_intensity [1] + each_top_selected_protein_protein_groups [1]),4)
            top_n_peptide_sum_intensity [2]= round((top_n_peptide_sum_intensity [2] + each_top_selected_protein_protein_groups [2]),4)
            ###top_n_spectra_sum_intensity [3]= round((top_n_spectra_sum_intensity [3] + each_top_selected_intensity [3]),4)

        if sum(top_n_peptide_sum_intensity) != 0:
            normalized_ratio_on_protein_level = [round ((top_n_peptide_sum_intensity [0]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [1]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [2]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_protein_level = [0,0,0]
               
        all_intensity_collection_protein_level [each_protein_protein_groups].insert (0,top_n_peptide_sum_intensity)
        all_intensity_collection_protein_level [each_protein_protein_groups].insert (0,normalized_ratio_on_protein_level)

    print ('len (all_intensity_collection_protein_level', len (all_intensity_collection_protein_level))
    write_by_rows = [['protein(groups)_accession','related_peptides','nor_pep_ra_+0','nor_pep_ra_+1','nor_pep_ra_+2','inten_+0','inten_+1','inten_+2','total_inten_all_cha']]

    for each_protein_protein_groups in list (all_intensity_collection_protein_level.keys()):
        
        if 0 in all_intensity_collection_protein_level[each_protein_protein_groups][0]:
            continue
    
        new_line = [str (each_protein_protein_groups)]
        
        related_peptides = []
        for each_key in all_intensity_collection_protein_level[each_protein_protein_groups][3].keys():
            ###print (each_key)
            related_peptides.append (each_key)
        new_line.append (str (related_peptides))
            
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][1]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][0][2]))
        
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][1]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_protein_groups][1][2]))
        
        new_line.append (str (sum (all_intensity_collection_protein_level[each_protein_protein_groups][1])))
        
        ###print ('str (all_intensity_collection_peptide_level[each_peptide_seq][-2:-1][0][1][3][1]')
        ###print (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1])
        ###new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][4][1][3][1]))
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Protein_level_normalized_ratios.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Protein_level_normalized_ratios csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    return gather_quantification_ratio_for_all_scan_number

'''test_dict ={'32885:GLVLIAFSQYLQQCPFDEHVK': [['2chargesy21quantification_ion+0', 'GLVLIAFSQYLQQCPFDEHVK', 1289.1529, '0'], ['3chargesy21quantification_ion+0', 'GLVLIAFSQYLQQCPFDEHVK', 859.7712, '0'], ['2chargesy21quantification_ion+1', 'GLVLIAFSQYLQQCPFDEHVK', 1289.6546, '0'], ['3chargesy21quantification_ion+1', 'GLVLIAFSQYLQQCPFDEHVK', 860.1057, 9277.2], ['2chargesy21quantification_ion+2', 'GLVLIAFSQYLQQCPFDEHVK', 1290.1563, '0'], ['3chargesy21quantification_ion+2', 'GLVLIAFSQYLQQCPFDEHVK', 860.4401, 23435.3], ['spectrum_information', [['m_over_z', 898.1307], ['retention_time', 3297.6], ['peptide', 'GLVLIAFSQYLQQCPFDEHVK'], ['mass', 2691.364], ['charge_states', 3], ['logP', 85.05], ['length', 21], ['ppm', 2.4], ['area', '1.05E+06'], ['protein_accession', 'P02769']]]], '25821:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, 372687.7], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 12817069.0], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, 653040.5], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, 28679616.0], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, 1022097.5], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 39195824.0], ['spectrum_information', [['m_over_z', 699.7344], ['retention_time', 2595.6], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 80.16], ['length', 18], ['ppm', 2.9], ['area', '1.03E+09'], ['protein_accession', 'P02769']]]], '24036:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, 4914.8], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 412320.6], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, 17596.9], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, 788351.4], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, 24494.3], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 1169443.6], ['spectrum_information', [['m_over_z', 699.7349], ['retention_time', 2418.0], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 75.92], ['length', 18], ['ppm', 3.6], ['area', '3.26E+07'], ['protein_accession', 'P02769']]]], '25338:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, 5493.2], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 182530.5], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, 10620.3], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, 369025.6], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, 12736.8], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 531666.5], ['spectrum_information', [['m_over_z', 699.7356], ['retention_time', 2547.6], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 66.73], ['length', 18], ['ppm', 4.6], ['area', '1.18E+07'], ['protein_accession', 'P02769']]]], '24603:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, '0'], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 195000.7], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, 17456.5], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, 494153.7], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, 23028.3], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 649308.2], ['spectrum_information', [['m_over_z', 699.7338], ['retention_time', 2474.4], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 61.18], ['length', 18], ['ppm', 2.0], ['area', '1.88E+07'], ['protein_accession', 'P02769']]]], '21915:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, '0'], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 2840.3], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, '0'], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, 15675.3], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, '0'], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 20942.2], ['spectrum_information', [['m_over_z', 699.7354], ['retention_time', 2209.8], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 43.52], ['length', 18], ['ppm', 4.3], ['area', '1.86E+06'], ['protein_accession', 'P02769']]]], '28740:VPQVSTPTLVEVSRSLGK': [['2chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 991.5611, '0'], ['3chargesy18quantification_ion+0', 'VPQVSTPTLVEVSRSLGK', 661.3767, 2751.0], ['2chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 992.0628, '0'], ['3chargesy18quantification_ion+1', 'VPQVSTPTLVEVSRSLGK', 661.7111, '0'], ['2chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 992.5645, '0'], ['3chargesy18quantification_ion+2', 'VPQVSTPTLVEVSRSLGK', 662.0456, 6184.4], ['spectrum_information', [['m_over_z', 699.7328], ['retention_time', 2884.8], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2096.1753], ['charge_states', 3], ['logP', 19.35], ['length', 18], ['ppm', 0.6], ['area', '1.47E+05'], ['protein_accession', 'P02769']]]], '19924:ECCHGDLLECADDRADLAK': [['2chargesy19quantification_ion+0', 'ECCHGDLLECADDRADLAK', 1166.9934, 103033.4], ['3chargesy19quantification_ion+0', 'ECCHGDLLECADDRADLAK', 778.3316, 4283132.0], ['2chargesy19quantification_ion+1', 'ECCHGDLLECADDRADLAK', 1167.4951, 235424.1], ['3chargesy19quantification_ion+1', 'ECCHGDLLECADDRADLAK', 778.666, 9893777.0], ['2chargesy19quantification_ion+2', 'ECCHGDLLECADDRADLAK', 1167.9968, 287037.9], ['3chargesy19quantification_ion+2', 'ECCHGDLLECADDRADLAK', 779.0005, 14092207.0], ['spectrum_information', [['m_over_z', 816.693], ['retention_time', 2014.2], ['peptide', 'ECCHGDLLECADDRADLAK'], ['mass', 2447.0427], ['charge_states', 3], ['logP', 79.42], ['length', 19], ['ppm', 5.9], ['area', '2.06E+08'], ['protein_accession', 'P02769']]]], '19588:ECCHGDLLECADDRADLAK': [['2chargesy19quantification_ion+0', 'ECCHGDLLECADDRADLAK', 1166.9934, '0'], ['3chargesy19quantification_ion+0', 'ECCHGDLLECADDRADLAK', 778.3316, 28342.4], ['2chargesy19quantification_ion+1', 'ECCHGDLLECADDRADLAK', 1167.4951, 11258.3], ['3chargesy19quantification_ion+1', 'ECCHGDLLECADDRADLAK', 778.666, 59374.9], ['2chargesy19quantification_ion+2', 'ECCHGDLLECADDRADLAK', 1167.9968, '0'], ['3chargesy19quantification_ion+2', 'ECCHGDLLECADDRADLAK', 779.0005, 78994.4], ['spectrum_information', [['m_over_z', 816.69], ['retention_time', 1981.2], ['peptide', 'ECCHGDLLECADDRADLAK'], ['mass', 2447.0427], ['charge_states', 3], ['logP', 36.6], ['length', 19], ['ppm', 2.2], ['area', '2.19E+06'], ['protein_accession', 'P02769']]]], '21954:YNGVFQECCQAEDK': [['2chargesy14quantification_ion+0', 'YNGVFQECCQAEDK', 916.8787, 13919.5], ['3chargesy14quantification_ion+0', 'YNGVFQECCQAEDK', 611.5884, 5967.2], ['2chargesy14quantification_ion+1', 'YNGVFQECCQAEDK', 917.3804, 34116.3], ['3chargesy14quantification_ion+1', 'YNGVFQECCQAEDK', 611.9228, 10222.1], ['2chargesy14quantification_ion+2', 'YNGVFQECCQAEDK', 917.8821, 41076.1], ['3chargesy14quantification_ion+2', 'YNGVFQECCQAEDK', 612.2573, 21712.0], ['spectrum_information', [['m_over_z', 649.9455], ['retention_time', 2212.2], ['peptide', 'YNGVFQECCQAEDK'], ['mass', 1946.8049], ['charge_states', 3], ['logP', 74.4], ['length', 14], ['ppm', 5.0], ['area', '9.12E+06'], ['protein_accession', 'P02769']]]]}
working_path = 'H:\\Ac-AG tag\\DIA scripts and analysis\\DIA result\\DIA analysis Ac-AG-BSA 111\\'

simpilified_test_dict = normalize_ratio_for_spec (working_path,test_dict)'''
